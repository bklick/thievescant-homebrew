Howdy! 

This module will be a repository for all of the 5e homebrew content and Foundry-friendly rules from www.yesthievescan.com.

For right now, it only includes one subclass - the Nightingale.

The compendia in this module use the Compendium Folders module, which you can download here:
https://foundryvtt.com/packages/compendium-folders

This module is not required. If you open the compendia without it, there will be a handful of junk entries that you can safely delete. These will look like items and will have a name like #[CF_tempEntity]. These are simply the markers for the folder structure if you happen to have that module.

Thanks for using my stuff!

Bartholomew Klick
Midnight, 8-31-2022